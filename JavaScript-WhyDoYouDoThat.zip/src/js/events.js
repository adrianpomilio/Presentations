/**
     * @fileOverview Cross Browser Event library
     * @author <a href="mailto:adrianpomilio@gmail.com">Adrian Pomilio</a>
     * @version 1
     */


/** @namespace */
var EVT = (function(e) {
	

	/**
     * Adds event listener
     * @param {string} obj represents the element that will have the event attached
	 * @param {string} type is a string representing the event type 'click' etc.
	 * @param {string} fn represents the callback function when event is triggered
     * @returns {object} returns an object with an event listener
     */
	e.addEvent = function(obj, type, fn){
		'use strict';
		if(obj && obj.addEventListener){
			return obj.addEventListener(type, fn, false);
		}else if (obj && obj.attachEvent){
			return obj.attachEvent('on'+type, fn);  
		}
	};
	/**
     * Removeevent listener
     * @param {string} obj represents the element that will have the event removed
	 * @param {string} type is a string representing the event type 'click' etc.
	 * @param {string} fn represents the callback function when event is triggered
     * @returns {object} returns an object with the even removed
     */
	e.removeEvent = function(obj, type, fn){
		'use strict';
		if(obj && obj.removeEventListener){
			return obj.removeEventListener(type, fn, false);
		}else if (obj && obj.detachEvent){
			return obj.detachEvent('on'+type, fn);  
		}
	};
	
	// primative demo of privacy
	e.privateTesting = function(){
	 var str =	privateTest();
		return str;
	}
	
	function privateTest(){
		console.log('nothing')
	};
	// end primative privacy demo
	
	return e;
}(EVT || {}));


// sample calls
// EVT.addEvent(A.$('divBlock'),'click',init) +++ add event listener while getting element

$(document).ready(function(){
	 
	var Todo = Backbone.Model.extend({
		
		defaults: function(){
			return {
				text: "something todo",
				done: false
			};
		},
		
		initialize: function(){
			if(!this.get("text")){
				this.set({'text':this.defaults.text});
			}
		},
		
		clear: function() {
	      this.destroy();
	    }
		
	});
	
	var TodoList = Backbone.Collection.extend({
		
		model:Todo,
		url: '../assets/todo.json'
	});
	
	var Todos = new TodoList;
	
	var TodoView = Backbone.View.extend({
		
		tagName: "li",
	
		template: _.template($('#item-template').html()),
		
		events: {
			'click a.destroy' : 'clear'
			
		},
		
		initialize: function(){
		
			this.model.bind('destroy', this.remove, this);
		},
		
		render: function() {
		      this.$el.html(this.template(this.model.toJSON()));
		      this.input = this.$('.edit');
		      return this;
		    },
		
		clear: function() {
			      this.model.clear();
			 }
		
	});
	
	var AppView = Backbone.View.extend({
		
		el: $('#todoapp'),
		
		events: {
		      "keypress #new-todo":  "createOnEnter"
		    },
		
		initialize: function() {

			      this.input = this.$("#new-todo");
			    
			      Todos.bind('add', this.addOne, this);
			      

			      this.main = $('#main');

			      Todos.fetch();
			    },
			
		render: function() {
				     
				      if (Todos.length) {
				        this.main.show();
				      } else {
				        this.main.hide();
				      }

				      this.allCheckbox.checked = !remaining;
				    },
					
			addOne: function(todo) {
					      var view = new TodoView({model: todo});
					      this.$("#todo-list").append(view.render().el);
					    },
		
			createOnEnter: function(e) {
						      if (e.keyCode != 13) return;
						      if (!this.input.val()) return;

						      Todos.create({text: this.input.val()});
						      this.input.val('');
						}
		
	});
	
	var App = new AppView;
	
});
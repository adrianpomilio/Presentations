function TodoCtrl($scope){
	$scope.todos = [{text:'create todo list', done:true},
		{text:'compare todo list', done:false}
		];
	
	$scope.addTodo = function(){
		$scope.todos.push({text:$scope.formTodoText, done:false});
		$scope.formTodoText = '';
	};
	
	$scope.getTotal = function(){
		
		return $scope.todos.length;
	};

	
};
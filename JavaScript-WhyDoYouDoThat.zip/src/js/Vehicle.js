var Vehicle = function (type){
	
	this.type = type;
	this.start = function() {
		return this.type + " is started";
	};
	
	// return this by default
};

// better way to create method on the prototype

/* Vehicle.prototype.say = function () {
	return this.type + " is started";
};*/

var truck = new Vehicle('truck');
console.log(typeof truck);
console.log(truck.start());

var truck1 = Vehicle('truck');
console.log(typeof truck1);
console.log(window.start());


/**
     * @fileOverview Example of JSDoc.
     * @author <a href="mailto:adrianpomilio@gmail.com">Adrian Pomilio</a>
     * @version 1
     */


/** @namespace */
    var APP = {
	
		/**
		 * Initializes any app controls
		 */
		init: function(){
			EVT.addEvent(document.getElementById('evtCheck'), 'click', APP.clickedIt)
		},
		
	
        /**
         * Returns the name given, very useless
         * @param {string} name is the name to return.
         * @returns {string}
         */
        person: function(name) {
            var _name = name;
            return _name;
        },

		clickedIt:function(){
			console.log('we clicked the link');
		}

    };



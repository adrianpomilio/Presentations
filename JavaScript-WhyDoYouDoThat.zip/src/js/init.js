require(["../lib/jquery-1.7.2.js",
	"../lib/underscore.js",
	"../js/app.js",
	"../js/events.js"
	], function(events){
   		EVT.privateTesting()
		
});